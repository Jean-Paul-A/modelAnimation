from base import typeassert, Structure
from featureMatrix import Feature
from mesh import Mesh
from perspective import Perspective
from PIL import Image, ImageDraw
import numpy as np
import cv2
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
import pygame


@typeassert(_meshes = list, _perspective = Perspective, _object = Feature, _camera = Feature)

class Rendering(Structure):
    _field = ['_meshes','_perspective', '_object', '_camera']
    def __str__(self):
        return 'Rendering Initialization: ' \
               '\nMesh Features: {0._meshes}' \
               '\nCamera Feature: {0._camera} '\
               '\nObject Feature: {0._object}'.format(self)

    @property
    def transMatrix(self):
        return self._perspective.ProjectionMatrix@np.linalg.pinv(self._camera.featureWorldMatrix)\
               @self._object.featureWorldMatrix

    def projection(self, originX=0.0, originY = 0.0):
        for mesh in self._meshes:
            vertices = np.column_stack((mesh._vertices, np.ones(len(mesh._vertices)))).T
            vPrime = self.transMatrix@vertices
            normalization = vPrime/np.where(vPrime[3]>1e-6,vPrime[3],1e-6)
            pixels2D = (normalization[:2]/normalization[2])
            x2D = (pixels2D[0] +1.0)* (self._perspective.width * 0.5) + originX
            y2D = (pixels2D[1] +1.0)* (self._perspective.height * 0.5) + originY
            points = np.array([x2D,y2D]).T
        return points

    # def Visualization(self, points, image=None):
    #     if image is None:
    #         renderImage = Image.new("RGB", (int(self._perspective.width),int(self._perspective.height)), (255, 255, 255))
    #     else:
    #         renderImage = image
    #     drawingContext = ImageDraw.Draw(renderImage)
    #     for mesh in self._meshes:
    #         for index, PointIndex in enumerate(mesh._facesVerticesIndex):
    #             print("F{}:".format(index),points[PointIndex],PointIndex)
    #
    #         #drawingContext.polygon(points[PointIndex], fill=(255, 0, 0), outline=(0, 0, 255), width=1)
    #         drawingContext.line(points[PointIndex], fill=(255, 0, 0), width=1)
    #         renderImage.show()
    #     return renderImage



"""

if __name__ == "__main__":
    kk = Mesh('./meshwriter/test.mesh')
    kk()
    meshes = []
    meshes.append(kk)
    Camera = Feature(_scale = (1.,1.,1.), _translate = (0.,-6.6,2.0), _rotation = (1.,0.,0.),_rotationAngle = 71.941)
    Object = Feature(_scale = (1.,1.,1.), _translate = (0.,0.,0.), _rotation = (1.,0.,0.),_rotationAngle = 0.)
    View = Perspective(40.,1., 100.,16, 9)
    temp = Rendering(meshes, View, Object,Camera)
    print(temp)
    print(temp._camera.featureWorldMatrix)
    print(temp._object.featureWorldMatrix)

    pts = temp.projection(-8,-4.5)

    print("Points",pts)
    fig, ax = plt.subplots()
    for mesh in temp._meshes:
        for index, PointIndex in enumerate(mesh._facesVerticesIndex):
            print("F{}:".format(index),pts[PointIndex],PointIndex)
            p = Polygon(pts[PointIndex], facecolor='b')
            ax.add_patch(p)
            ax.set_xlim([-8, 8])
            ax.set_ylim([-4.5, 4.5])
            #drawingContext.polygon(points[PointIndex], fill=(255, 0, 0), outline=(0, 0, 255), width=1)
    plt.show()"""

#     canvas = np.ones((160, 90, 3), dtype="uint8")
#     canvas *= 255
#     # 初始化点集
# #    points = np.array([[100, 50], [200, 300], [700, 200], [500, 100]], np.int32)
#     # 点集矩阵变形
#     points = pts.reshape((-1, 1, 2))
#     print("points after reshape")
#     # RESHAPE TO N*1*2
#     print(points)
#     cv2.polylines(canvas, pts=[points], isClosed=True, color=(0, 0, 255), thickness=3)
#
#     cv2.imshow("polylines", canvas)
#     cv2.imwrite("polylines.png", canvas)
#
#     cv2.waitKey(0)


if __name__ == "__main__":
    kk = Mesh('./meshwriter/Drone.mesh')
    kk()
    meshes = []
    meshes.append(kk)
    Camera = Feature(_scale = (1.,1.,1.), _translate = (7.358,-6.925,4.958), _rotation = (0.773,0.334,0.539), _rotationAngle = 77.4)
    Object = Feature(_scale = (1.,1.,1.), _translate = (0.,0.,0.), _rotation = (0.,1.,0.),_rotationAngle = 0.)
    View = Perspective(40.,1., 100.,960, 540)
    temp = Rendering(meshes, View, Object,Camera)
    print(temp)
    print(temp._camera.featureWorldMatrix)
    print(temp._object.featureWorldMatrix)

    pts = temp.projection()

    print("Points",pts)
    # fig, ax = plt.subplots()
    # for mesh in temp._meshes:
    #     for index, PointIndex in enumerate(mesh._facesVerticesIndex):
    #         print("F{}:".format(index),pts[PointIndex],PointIndex)
    #         p = Polygon(pts[PointIndex], facecolor='b')
    #         ax.add_patch(p)
    #         ax.set_xlim([-8, 8])
    #         ax.set_ylim([-4.5, 4.5])
    #         #drawingContext.polygon(points[PointIndex], fill=(255, 0, 0), outline=(0, 0, 255), width=1)
    # plt.show()

    pygame.init()
    white = (255, 255, 255)
    black = (0, 0, 0)
    red = (255, 0, 0)
    green = (0, 255, 0)
    blue = (0, 0, 255)
    gameDisplay = pygame.display.set_mode((960, 540))
    gameDisplay.fill(black)
    pixAr = pygame.PixelArray(gameDisplay)

    for mesh in temp._meshes:
        for index, PointIndex in enumerate(mesh._facesVerticesIndex):
            print("F{}:".format(index),pts[PointIndex],PointIndex)
            pygame.draw.polygon(gameDisplay, blue, pts[PointIndex])

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
        pygame.display.update()

#https://pythonprogramming.net/pygame-drawing-shapes-objects/
